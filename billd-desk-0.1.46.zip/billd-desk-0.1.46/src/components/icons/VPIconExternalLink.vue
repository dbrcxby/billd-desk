<template>
  <div class="link-ico"></div>
</template>

<style lang="scss" scoped>
.link-ico {
  display: inline-block;
  @include setBackground('@/assets/img/link.png');
}
</style>
