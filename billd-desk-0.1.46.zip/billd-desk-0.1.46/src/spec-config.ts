export const prodDomain = 'hsslive.cn';
